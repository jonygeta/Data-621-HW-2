# Assignment no. 2: Classification metrics

Develop custom R functions to evaluate performance of classification algorithms.