# DATA-621 Fall '19: Critical thinking group no. 2

The semester's projects

Members:

* Ben H.
* Yohannes Deboch
*
*
*
*
